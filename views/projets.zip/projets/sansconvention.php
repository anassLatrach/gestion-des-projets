<?php 
	$projetAff = new ProjetModel();
	$res = $projetAff->afficherEncadrant();
    $tech = $projetAff->afficherTech();
    $cat = $projetAff->afficherCat();

   
	?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<!-- BEGIN: Subheader -->
					<div class="m-subheader ">
						<div class="d-flex align-items-center">
							<div class="mr-auto">
								<h3 class="m-subheader__title m-subheader__title--separator">
									Etudiants
								</h3>
								<ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
									<li class="m-nav__item m-nav__item--home">
										<a href="<?php echo ROOT_PATH; ?>" class="m-nav__link m-nav__link--icon">
											<i class="m-nav__link-icon la la-home"></i>
										</a>
									</li>
									<li class="m-nav__separator">
										-
									</li>
									<li class="m-nav__item">
										<a href="<?php echo ROOT_PATH; ?>etudiants/ajouter" class="m-nav__link">
											<span class="m-nav__link-text">
												Ajouter
											</span>
										</a>
									</li>
									<li class="m-nav__separator">
										-
									</li>
									<li class="m-nav__item">
										<a href="<?php echo ROOT_PATH; ?>etudiants/afficher" class="m-nav__link">
											<span class="m-nav__link-text">
												Afficher
											</span>
										</a>
									</li>
								</ul>
							</div>
					</div>
					<!-- END: Subheader -->
					<div class="m-content">
						<div class="row">
							<div class="col-lg-12">
								<!--begin::Portlet-->
								<div class="m-portlet">
									<div class="m-portlet__head">
										<div class="m-portlet__head-caption">
											<div class="m-portlet__head-title">
												<h3 class="m-portlet__head-text">
													Sans Convention
												</h3>
											</div>
										</div>
									</div>
                                    
									<div class="m-portlet__body">
										<ul class="nav nav-tabs" role="tablist">
											<li class="nav-item">
												<a class="nav-link active" data-toggle="tab" href="#m_tabs_1_1">
													Active
												</a>
											</li>
                                            <li class="nav-item">
												<a class="nav-link" data-toggle="tab" href="#m_tabs_1_2">
													Dropdown
												</a>
											</li>
											
											<li class="nav-item">
												<a class="nav-link" data-toggle="tab" href="#m_tabs_1_3">
													Link
												</a>
											</li>
											<li class="nav-item">
												<a class="nav-link disabled" data-toggle="tab" href="#m_tabs_1_4">
													Disabled
												</a>
											</li>
										</ul>
										<div class="tab-content">
											<div class="tab-pane active" id="m_tabs_1_1" role="tabpanel">
												<form class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" method="post" action="<?php $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
										<div class="m-portlet__body">
											<div class="form-group m-form__group row">
												<div class="col-lg-6">
													<label>
													Titre du projet :
													</label>
													<input type="text" name="titre_projet" class="form-control m-input" placeholder="ex: Gestion des Etudiants" >
												</div>
												<div class="col-lg-6">
													<label class="">
													Semestre :
													</label>
													<select name="semestre" class="form-control m-input">
																<option value="">
                                                                            Select 
                                                                        </option>
                                                                        <option value="1">
                                                                            S1
                                                                        </option>
                                                                        <option value="2">
                                                                            S2
                                                                        </option>
                                                                    </select>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<div class="col-lg-6">
													<label>
													Debut:
													</label>
													<div class="m-input-icon m-input-icon--right">
													<input class="form-control m-input" type="date" name="date_debut" id="example-date-input">
													</div>
												</div>
												<div class="col-lg-6">
													<label>
													Fin:
													</label>
													<div class="m-input-icon m-input-icon--right">
													<input class="form-control m-input" type="date" name="date_fin" id="example-date-input">
																
													</div>
												</div>
											</div>


											<div class="form-group m-form__group row">
												<div class="col-lg-6">
													<label>
													Niveau:
													</label>
													<div class="m-input-icon m-input-icon--right">
													<select class="form-control m-input" name="niveau" id="exampleSelect1" required>
													<option value="1">
														1
													</option>
													<option value="2">
														2
													</option>3
													<option value="3">
														3
													</option>
													<option value="4">
														4
													</option>
													<option value="5">
														5
													</option>
												</select>
													</div>
												</div>
												<div class="col-lg-6">
													<label>
													Encadrant:
													</label>
													<div class="m-input-icon m-input-icon--right">
													<select  name="encadrant" class="form-control m-input">
																	<option value="">
                                                                            Choisir :
                                                                        </option>
                                                                        <?php foreach($res as $item) : ?>
                                                                        <option value=<?php echo $item['id_encadrant']?>>
																		<?php echo $item['nom_encadrant'] ."  ".$item['prenom_encadrant'];  ?>
                                                                        </option>
																	<?php endforeach;?>
                                                                    </select>			
													</div>
												</div>
											</div>

											
											


											
										</div>
										<div class="m-portlet__foot m-portlet__no-border m-portlet__foot--fit">
											<div class="m-form__actions m-form__actions--solid">
												<div class="row">
													<div class="col-lg-6">
														<input type="submit" value="Ajouter" name="submit" class="btn btn-primary">
														<button type="reset" class="btn btn-secondary">
															Annuler
														</button>
													</div>
												</div>
											</div>
										</div>
									</form>
                                            </div>
											<div class="tab-pane" id="m_tabs_1_2" role="tabpanel">
                                                
									<div class="form-group m-form__group row">
										<label class="col-form-label col-lg-3 col-sm-12">
											Live Search
										</label>
										<div class="col-lg-4 col-md-9 col-sm-12">
 
                                      <select class="form-control m-bootstrap-select m_selectpicker" data-live-search="true" id="slct1" name="slct1" onchange="populate(this.id,'slct2')">
                                          <option value=""></option>
                                          <?php foreach($cat as $itemCat) :?>
                                          <?php 
                                          $id= $itemCat['id_categorie'];
                                          
                                          ?>
                                             <script>
function populate(s1,s2){
var s1 = document.getElementById(s1);
	var s2 = document.getElementById(s2);
	s2.innerHTML = "";
    <?php $catId = $projetAff->afficherCatbyID($id); ?>
	if(s1.value == <?php echo '"'.$itemCat['nom_categorie'].'"'?>){
		var optionArray = [<?php 
            foreach($catId as $itemcatID) {
             echo  '"'. $itemcatID["nom_technologie"] .'",';
}?>
        ];
	}
	
	for(var option in optionArray){
		var pair = optionArray[option].split(',');
		var newOption = document.createElement("option");
		newOption.value = pair[0];
		newOption.innerHTML = pair[0];
		s2.options.add(newOption);
	}
}
</script>

                                               <option value="<?php echo $id; ?>">
                                                <?php echo $itemCat['nom_categorie'];  ?>
                                                </option>
                                            <?php endforeach;?>
                                          
                                    </select>
                                                Choose Car Model:
                                                <select  id="slct2" name="slct2" ></select>      
                                            
                                            
	
                                            
                                            
											<!--<select >
                                             <?php/* foreach($tech as $itemTech) : ?>
                                                
                                                <option value=<?php echo $itemTech['id_technologie']?>>
                                                <?php echo $itemTech['nom_technologie'];  ?>
                                                </option>
                                            <?php endforeach;*/?>
											</select>-->
									</div>
								</div>          
                                            </div>
											<div class="tab-pane" id="m_tabs_1_3" role="tabpanel">
												Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged
											</div>
											<div class="tab-pane" id="m_tabs_1_4" role="tabpanel">
												Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and
											</div>
										</div>
									</div>
                                </div>


									<!--
									<form class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed" method="post" action="<?php $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
										<div class="m-portlet__body">
											<div class="form-group m-form__group row">
												<div class="col-lg-6">
													<label>
													Titre du projet :
													</label>
													<input type="text" name="titre_projet" class="form-control m-input" placeholder="ex: Gestion des Etudiants" >
												</div>
												<div class="col-lg-6">
													<label class="">
													Semestre :
													</label>
													<select name="semestre" class="form-control m-input">
																<option value="">
                                                                            Select 
                                                                        </option>
                                                                        <option value="1">
                                                                            S1
                                                                        </option>
                                                                        <option value="2">
                                                                            S2
                                                                        </option>
                                                                    </select>
												</div>
											</div>
											<div class="form-group m-form__group row">
												<div class="col-lg-6">
													<label>
													Debut:
													</label>
													<div class="m-input-icon m-input-icon--right">
													<input class="form-control m-input" type="date" name="date_debut" id="example-date-input">
													</div>
												</div>
												<div class="col-lg-6">
													<label>
													Fin:
													</label>
													<div class="m-input-icon m-input-icon--right">
													<input class="form-control m-input" type="date" name="date_fin" id="example-date-input">
																
													</div>
												</div>
											</div>


											<div class="form-group m-form__group row">
												<div class="col-lg-6">
													<label>
													Niveau:
													</label>
													<div class="m-input-icon m-input-icon--right">
													<select class="form-control m-input" name="niveau" id="exampleSelect1" required>
													<option value="1">
														1
													</option>
													<option value="2">
														2
													</option>3
													<option value="3">
														3
													</option>
													<option value="4">
														4
													</option>
													<option value="5">
														5
													</option>
												</select>
													</div>
												</div>
												<div class="col-lg-6">
													<label>
													Encadrant:
													</label>
													<div class="m-input-icon m-input-icon--right">
													<select  name="encadrant" class="form-control m-input">
																	<option value="">
                                                                            Choisir :
                                                                        </option>
                                                                        <?php foreach($res as $item) : ?>
                                                                        <option value=<?php echo $item['id_encadrant']?>>
																		<?php echo $item['nom_encadrant'] ."  ".$item['prenom_encadrant'];  ?>
                                                                        </option>
																	<?php endforeach;?>
                                                                    </select>			
													</div>
												</div>
											</div>

											
											<div class="form-group m-form__group row">
												<label for="exampleSelect1">
													Niveau:
												</label>
												
										<div class="col-lg-4 col-md-9 col-sm-12">
											<select class="form-control" id="m_selectsplitter_2">
												<optgroup label="Group 1">
													<option value="1" selected>
														Option 1
													</option>
													<option value="2">
														Option 2
													</option>
													<option value="3">
														Option 3
													</option>
													<option value="4">
														Option 4
													</option>
												</optgroup>
												<optgroup label="Group 2">
													<option value="5">
														Option 5
													</option>
													<option value="6">
														Option 6
													</option>
													<option value="7">
														Option 7
													</option>
													<option value="8">
														Option 8
													</option>
												</optgroup>
												<optgroup label="Group 3">
													<option value="5">
														Option 9
													</option>
													<option value="6">
														Option 10
													</option>
													<option value="7">
														Option 11
													</option>
													<option value="8">
														Option 12
													</option>
												</optgroup>
												<optgroup label="Group 4">
													<option value="5">
														Option 13
													</option>
													<option value="6">
														Option 14
													</option>
													<option value="7">
														Option 15
													</option>
													<option value="8">
														Option 16
													</option>
												</optgroup>
												<optgroup label="Group 5">
													<option value="5">
														Option 17
													</option>
													<option value="6">
														Option 18
													</option>
													<option value="7">
														Option 19
													</option>
													<option value="8">
														Option 20
													</option>
												</optgroup>
											</select>
										</div>
											</div>



											
										</div>
										<div class="m-portlet__foot m-portlet__no-border m-portlet__foot--fit">
											<div class="m-form__actions m-form__actions--solid">
												<div class="row">
													<div class="col-lg-6">
														<input type="submit" value="Ajouter" name="submit" class="btn btn-primary">
														<button type="reset" class="btn btn-secondary">
															Annuler
														</button>
													</div>
												</div>
											</div>
										</div>
									</form>-->
									<!--end::Form--
								</div>-->
								<!--end::Portlet-->
							</div>
						</div>
	</div>
</div>

    
    <script type="text/javascript">
    //== Class definition

var BootstrapSelectsplitter = function () {
    
    //== Private functions
    var demos = function () {
        // minimum setup
        $('#m_selectsplitter_1, #m_selectsplitter_2').selectsplitter();
    }

    return {
        // public functions
        init: function() {
            demos(); 
        }
    };
}();

jQuery(document).ready(function() {    
    BootstrapSelectsplitter.init();
});
    
    </script>